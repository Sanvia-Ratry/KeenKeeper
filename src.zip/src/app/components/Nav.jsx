"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useState } from "react";
import { AiOutlineClose, AiOutlineHome, AiOutlineMenu } from "react-icons/ai";
import { RiTimeLine } from "react-icons/ri";
import { TfiStatsDown } from "react-icons/tfi";
const navLinks = [
  { name: "Home", href: "/", icon: AiOutlineHome },
  { name: "Timeline", href: "/timeline", icon: RiTimeLine },
  { name: "Stats", href: "/stats", icon: TfiStatsDown },
];

const Nav = () => {
  const pathname = usePathname();

  return (
    <div className="flex flex-col gap-1 md:flex-row justify-between items-center py-4 px-5 md:px-20 border border-b border-gray-200">
      <div className="text-2xl font-medium text-font-darkGreen">
        <span className="text-[#1f2937] font-extrabold">Keen</span>Keeper
      </div>
      <div className="flex gap-0.5 md:gap-1">
        {navLinks.map((link) => {
          const ReactIcons = link.icon;
          const isActive = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`${isActive ? "border rounded-sm bg-green-800 text-white" : ""}
            flex gap-1 items-center text-xs md:text-xl px-2.5 md:px-3 lg:px-4 py-3 text-[#64748b] font-medium`}
            >
              <ReactIcons className="h-5 w-6"></ReactIcons>
              <span>{link.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default Nav;
