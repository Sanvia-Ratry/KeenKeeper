import { Geist } from "next/font/google";
import "./globals.css";
import Nav from "@/app/components/Nav";
import Footer from "./components/Footer";
import AppProvider from "./context/AppContext";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const geist = Geist({
  variable: "--font-geist",
  subsets: ["latin"],
});

export const metadata = {
  title: "Keen Keeper",
  description: "A web app that keeps track of your recent contact history with close friends.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${geist.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col">
        <AppProvider>
          <Nav></Nav>
          <main className="flex-1 bg-[#f8fafc]">{children}</main>
          <ToastContainer
            position="top-right"
            autoClose={5000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick={false}
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            theme="light"
          />
          <Footer></Footer>
        </AppProvider>
      </body>
    </html>
  );
}
